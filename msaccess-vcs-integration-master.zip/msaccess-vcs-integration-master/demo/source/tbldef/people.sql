CREATE TABLE [people] (
  [id] AUTOINCREMENT CONSTRAINT [PrimaryKey] PRIMARY KEY  UNIQUE  NOT NULL ,
  [full_name] VARCHAR (100),
  [favorite_color] LONG 
)
