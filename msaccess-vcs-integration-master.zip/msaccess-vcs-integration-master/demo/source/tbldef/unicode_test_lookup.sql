CREATE TABLE [unicode_test_lookup] (
  [id] LONG  CONSTRAINT [PrimaryKey] PRIMARY KEY  UNIQUE  NOT NULL ,
  [value] VARCHAR (100)
)
