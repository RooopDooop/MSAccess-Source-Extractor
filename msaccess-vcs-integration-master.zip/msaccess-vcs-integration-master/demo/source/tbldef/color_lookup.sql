CREATE TABLE [color_lookup] (
  [id] LONG  CONSTRAINT [PrimaryKey] PRIMARY KEY  UNIQUE  NOT NULL ,
  [color] VARCHAR (15)
)
