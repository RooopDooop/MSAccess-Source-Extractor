demo\
=====

Databases supplied for convenience

`demo.accdb`

Use this for:

* trying out this project
* for testing updates to this project

`blank.accdb`

Use this for:

* testing importing
* a base for your own projects, to supply with source controlled files to other people
